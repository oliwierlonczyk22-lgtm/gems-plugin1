package pl.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class GemPlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final double DROP_CHANCE = 0.08; // szansa na gema z moba
    private static final int SLOT = 4;

    enum Gem {
        DASH("Dash", Material.AMETHYST_SHARD, NamedTextColor.LIGHT_PURPLE, 30),
        DOUBLE_JUMP("Double Jump", Material.FEATHER, NamedTextColor.WHITE, 30),
        SONIC_BOOM("Sonic Boom", Material.ECHO_SHARD, NamedTextColor.DARK_AQUA, 45),
        PEARL("Ender Pearl", Material.ENDER_EYE, NamedTextColor.DARK_PURPLE, 30),
        FIREBALL("Fireball", Material.FIRE_CHARGE, NamedTextColor.RED, 40),
        WIND("Wind Charge", Material.WIND_CHARGE, NamedTextColor.AQUA, 30),
        LIGHTNING("Lightning", Material.LIGHTNING_ROD, NamedTextColor.YELLOW, 45),
        BLINK("Blink", Material.CHORUS_FRUIT, NamedTextColor.LIGHT_PURPLE, 30),
        SLAM("Ground Slam", Material.MACE, NamedTextColor.GRAY, 40),
        HEAL("Heal", Material.GLISTERING_MELON_SLICE, NamedTextColor.GREEN, 60),
        FREEZE("Freeze Aura", Material.BLUE_ICE, NamedTextColor.BLUE, 50),
        VANISH("Vanish", Material.GLASS_PANE, NamedTextColor.DARK_GRAY, 60),
        SHRINK("Shrink", Material.SLIME_BALL, NamedTextColor.GREEN, 60),
        VAMPIRE("Vampire", Material.REDSTONE, NamedTextColor.DARK_RED, 50),
        PULL("Gravity Pull", Material.COMPASS, NamedTextColor.GOLD, 35),
        METEOR("Meteor", Material.MAGMA_CREAM, NamedTextColor.GOLD, 60),
        SPEED_BURST("Speed Burst", Material.SUGAR, NamedTextColor.WHITE, 40),
        RAGE("Rage", Material.BLAZE_POWDER, NamedTextColor.RED, 60),
        LAUNCH("Launch", Material.FIREWORK_ROCKET, NamedTextColor.AQUA, 35),
        TIME_STOP("Time Stop", Material.CLOCK, NamedTextColor.YELLOW, 60),
        POISON("Poison Cloud", Material.SPIDER_EYE, NamedTextColor.DARK_GREEN, 45),
        SHIELD("Shield", Material.SHIELD, NamedTextColor.BLUE, 50),
        ARROW_RAIN("Arrow Rain", Material.ARROW, NamedTextColor.GRAY, 55);

        final String label; final Material mat; final TextColor color; final int cooldown;
        Gem(String l, Material m, TextColor c, int cd) { label = l; mat = m; color = c; cooldown = cd; }
    }

    static class GemHolder implements InventoryHolder {
        Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    private NamespacedKey itemKey, equippedKey;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> shrunk = new HashSet<>();
    private final Set<String> dropped = new HashSet<>();
    private File dropFile;
    private final Random rnd = new Random();

    @Override
    public void onEnable() {
        itemKey = new NamespacedKey(this, "gem_type");
        equippedKey = new NamespacedKey(this, "equipped_gem");
        dropFile = new File(getDataFolder(), "dropped.yml");
        loadDropped();
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("gem").setExecutor(this);
        getCommand("gem").setTabCompleter(this);
        for (Player p : Bukkit.getOnlinePlayers()) refreshFlight(p);

        // anty-latanie: odbiera lot i oddaje mozliwosc 2x spacji dopiero po wyladowaniu
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!survivalLike(p) || equipped(p) == null) continue;
                if (p.isFlying()) {
                    p.setFlying(false);
                    p.setAllowFlight(false);
                } else if (!p.getAllowFlight() && p.isOnGround()) {
                    p.setAllowFlight(true);
                }
            }
        }, 2L, 2L);
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof GemHolder) p.closeInventory();
            unshrink(p);
        }
    }

    // ---------- zapis dropow ----------

    private void loadDropped() {
        dropped.clear();
        if (dropFile.exists()) dropped.addAll(YamlConfiguration.loadConfiguration(dropFile).getStringList("dropped"));
    }

    private void saveDropped() {
        try {
            getDataFolder().mkdirs();
            YamlConfiguration c = new YamlConfiguration();
            c.set("dropped", new ArrayList<>(dropped));
            c.save(dropFile);
        } catch (IOException ex) {
            getLogger().warning("Nie udalo sie zapisac dropped.yml: " + ex.getMessage());
        }
    }

    // ---------- przedmiot / stan ----------

    private ItemStack makeItem(Gem g) {
        ItemStack it = new ItemStack(g.mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("◆ " + g.label + " Gem", g.color).decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                Component.text("Wloz w /gem, aby wyposazyc.", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("Uzycie: 2x spacja", NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false),
                Component.text("Cooldown: " + g.cooldown + "s", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)));
        m.setEnchantmentGlintOverride(true);
        m.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, g.name());
        it.setItemMeta(m);
        return it;
    }

    private Gem gemOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        String s = it.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
        if (s == null) return null;
        try { return Gem.valueOf(s); } catch (IllegalArgumentException e) { return null; }
    }

    private Gem equipped(Player p) {
        String s = p.getPersistentDataContainer().get(equippedKey, PersistentDataType.STRING);
        if (s == null) return null;
        try { return Gem.valueOf(s); } catch (IllegalArgumentException e) { return null; }
    }

    private void setEquipped(Player p, Gem g) {
        if (g == null) p.getPersistentDataContainer().remove(equippedKey);
        else p.getPersistentDataContainer().set(equippedKey, PersistentDataType.STRING, g.name());
        refreshFlight(p);
    }

    private boolean survivalLike(Player p) {
        return p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE;
    }

    private void refreshFlight(Player p) {
        if (!survivalLike(p)) return;
        boolean has = equipped(p) != null;
        p.setAllowFlight(has);
        if (!has) p.setFlying(false);
    }

    // ---------- drop z mobow (kazdy gem tylko raz) ----------

    @EventHandler
    public void onMobDeath(EntityDeathEvent e) {
        if (e.getEntity() instanceof Player) return;
        Player killer = e.getEntity().getKiller();
        if (killer == null) return;
        List<Gem> left = Arrays.stream(Gem.values()).filter(g -> !dropped.contains(g.name())).toList();
        if (left.isEmpty() || rnd.nextDouble() > DROP_CHANCE) return;

        Gem g = left.get(rnd.nextInt(left.size()));
        dropped.add(g.name());
        saveDropped();

        e.getEntity().getWorld().dropItemNaturally(e.getEntity().getLocation(), makeItem(g), item -> {
            item.setUnlimitedLifetime(true);
            item.setInvulnerable(true);
            item.setGlowing(true);
        });
        Bukkit.broadcast(Component.text(killer.getName() + " zdobyl gem: ", NamedTextColor.GRAY)
                .append(Component.text(g.label, g.color)));
    }

    // ---------- komenda i GUI ----------

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length >= 1 && s.hasPermission("gem.admin")) {
            if (a[0].equalsIgnoreCase("reset")) {
                dropped.clear();
                saveDropped();
                s.sendMessage("Zresetowano liste wypadnietych gemow.");
                return true;
            }
            if (a[0].equalsIgnoreCase("list")) {
                StringBuilder sb = new StringBuilder("Wypadly: ");
                for (Gem g : Gem.values()) if (dropped.contains(g.name())) sb.append(g.name().toLowerCase()).append(" ");
                sb.append("(").append(dropped.size()).append("/").append(Gem.values().length).append(")");
                s.sendMessage(sb.toString());
                return true;
            }
            if (a[0].equalsIgnoreCase("give") && a.length >= 2) {
                Gem g;
                try { g = Gem.valueOf(a[1].toUpperCase()); } catch (IllegalArgumentException ex) { s.sendMessage("Nieznany gem."); return true; }
                Player target = a.length >= 3 ? Bukkit.getPlayer(a[2]) : (s instanceof Player pl ? pl : null);
                if (target == null) { s.sendMessage("Nie znaleziono gracza."); return true; }
                target.getInventory().addItem(makeItem(g));
                s.sendMessage("Dano gema " + g.label + ".");
                return true;
            }
        }
        if (!(s instanceof Player p)) { s.sendMessage("Tylko dla graczy."); return true; }
        openGui(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("gem.admin")) return List.of();
        if (a.length == 1) return List.of("give", "list", "reset");
        if (a.length == 2 && a[0].equalsIgnoreCase("give"))
            return Arrays.stream(Gem.values()).map(g -> g.name().toLowerCase()).toList();
        return List.of();
    }

    private void openGui(Player p) {
        GemHolder h = new GemHolder();
        h.inv = Bukkit.createInventory(h, 9, Component.text("Gem - wloz w srodkowy slot"));
        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta pm = pane.getItemMeta();
        pm.displayName(Component.text(" "));
        pane.setItemMeta(pm);
        for (int i = 0; i < 9; i++) if (i != SLOT) h.inv.setItem(i, pane);
        Gem cur = equipped(p);
        if (cur != null) {
            h.inv.setItem(SLOT, makeItem(cur));
            setEquipped(p, null);
        }
        p.openInventory(h.inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof GemHolder)) return;
        ClickType ct = e.getClick();
        if (ct.isShiftClick() || ct == ClickType.DOUBLE_CLICK || ct == ClickType.NUMBER_KEY
                || ct == ClickType.SWAP_OFFHAND) {
            e.setCancelled(true);
            return;
        }
        if (e.getClickedInventory() == e.getView().getTopInventory()) {
            if (e.getRawSlot() != SLOT) { e.setCancelled(true); return; }
            ItemStack cursor = e.getCursor();
            if (cursor != null && !cursor.getType().isAir() && gemOf(cursor) == null) e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof GemHolder)) return;
        for (int slot : e.getRawSlots()) if (slot < 9) { e.setCancelled(true); return; }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof GemHolder)) return;
        Player p = (Player) e.getPlayer();
        ItemStack it = e.getInventory().getItem(SLOT);
        Gem g = gemOf(it);
        if (g != null) {
            if (it.getAmount() > 1) {
                ItemStack extra = it.clone();
                extra.setAmount(it.getAmount() - 1);
                p.getInventory().addItem(extra).values().forEach(d -> p.getWorld().dropItem(p.getLocation(), d));
            }
            setEquipped(p, g);
            p.sendMessage(Component.text("Wyposazono: ", NamedTextColor.GRAY).append(Component.text(g.label, g.color))
                    .append(Component.text(" (2x spacja)", NamedTextColor.GRAY)));
        } else {
            setEquipped(p, null);
        }
    }

    // ---------- 2x spacja ----------

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        Player p = e.getPlayer();
        if (!survivalLike(p) || !e.isFlying()) return;
        Gem g = equipped(p);
        if (g == null) return;
        e.setCancelled(true);
        p.setFlying(false);
        p.setAllowFlight(false); // odzyska dopiero po wyladowaniu (anty-spam)
        use(p, g);
    }

    @EventHandler
    public void onGamemode(PlayerGameModeChangeEvent e) {
        Bukkit.getScheduler().runTask(this, () -> refreshFlight(e.getPlayer()));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) { refreshFlight(e.getPlayer()); }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { unshrink(e.getPlayer()); }

    // ---------- abilitki ----------

    private Location target(Player p, int range) {
        Entity te = p.getTargetEntity(range);
        if (te != null) return te.getLocation();
        var b = p.getTargetBlockExact(range);
        if (b == null) return null;
        return b.getLocation().add(0.5, 1, 0.5);
    }

    private void heal(Player p, double amount) {
        AttributeInstance max = p.getAttribute(Attribute.MAX_HEALTH);
        double mh = max != null ? max.getValue() : 20;
        p.setHealth(Math.min(mh, p.getHealth() + amount));
    }

    private void use(Player p, Gem g) {
        long now = System.currentTimeMillis();
        Long next = cooldowns.get(p.getUniqueId());
        if (next != null && now < next) {
            double left = (next - now) / 1000.0;
            p.sendActionBar(Component.text(String.format("%s: cooldown %.0fs", g.label, Math.ceil(left)), NamedTextColor.RED));
            return;
        }
        cooldowns.put(p.getUniqueId(), now + g.cooldown * 1000L);
        World w = p.getWorld();
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection();

        switch (g) {
            case DASH -> {
                p.setVelocity(dir.clone().setY(0.15).normalize().multiply(1.8));
                w.spawnParticle(Particle.CLOUD, p.getLocation(), 20, 0.3, 0.1, 0.3, 0.02);
                w.playSound(p.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1f, 1f);
            }
            case DOUBLE_JUMP -> {
                p.setVelocity(p.getVelocity().setY(0.95));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 80, 0));
                w.spawnParticle(Particle.CLOUD, p.getLocation(), 15, 0.3, 0.1, 0.3, 0.02);
                w.playSound(p.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1f, 1.3f);
            }
            case SONIC_BOOM -> {
                w.playSound(eye, Sound.ENTITY_WARDEN_SONIC_BOOM, 1f, 1f);
                Set<UUID> hit = new HashSet<>();
                for (int i = 1; i <= 15; i++) {
                    Location l = eye.clone().add(dir.clone().multiply(i));
                    w.spawnParticle(Particle.SONIC_BOOM, l, 1);
                    for (LivingEntity le : w.getNearbyLivingEntities(l, 1.2)) {
                        if (le.equals(p) || !hit.add(le.getUniqueId())) continue;
                        le.damage(10, p);
                        le.setVelocity(dir.clone().multiply(0.8).setY(0.3));
                    }
                }
            }
            case PEARL -> p.launchProjectile(EnderPearl.class);
            case FIREBALL -> {
                Fireball f = p.launchProjectile(Fireball.class, dir.clone().multiply(1.2));
                f.setYield(4f); // jak TNT
                f.setIsIncendiary(false);
            }
            case WIND -> p.launchProjectile(WindCharge.class);
            case LIGHTNING -> {
                Location t = target(p, 30);
                if (t == null) { refund(p); return; }
                w.strikeLightning(t);
            }
            case BLINK -> {
                RayTraceResult r = w.rayTraceBlocks(eye, dir, 8, FluidCollisionMode.NEVER, true);
                Vector dest = (r == null) ? eye.toVector().add(dir.clone().multiply(8))
                        : r.getHitPosition().subtract(dir.clone().multiply(0.6));
                Location to = dest.toLocation(w, eye.getYaw(), eye.getPitch()).subtract(0, 1.62, 0);
                w.spawnParticle(Particle.PORTAL, p.getLocation(), 40, 0.4, 0.8, 0.4, 0.5);
                p.teleport(to);
                w.playSound(to, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
            }
            case SLAM -> {
                w.spawnParticle(Particle.EXPLOSION, p.getLocation(), 3, 1, 0.1, 1);
                w.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.2f);
                for (LivingEntity le : w.getNearbyLivingEntities(p.getLocation(), 5)) {
                    if (le.equals(p)) continue;
                    le.damage(6, p);
                    Vector away = le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
                    if (away.lengthSquared() > 0) away.normalize().multiply(0.7);
                    le.setVelocity(away.setY(0.8));
                }
            }
            case HEAL -> {
                heal(p, 8);
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 0));
                w.spawnParticle(Particle.HEART, p.getLocation().add(0, 1.8, 0), 8, 0.4, 0.3, 0.4);
                w.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
            }
            case FREEZE -> {
                w.spawnParticle(Particle.SNOWFLAKE, p.getLocation().add(0, 1, 0), 80, 3, 1, 3, 0.02);
                w.playSound(p.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 0.6f);
                for (LivingEntity le : w.getNearbyLivingEntities(p.getLocation(), 6)) {
                    if (le.equals(p)) continue;
                    le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 3));
                    le.setFreezeTicks(200);
                }
            }
            case VANISH -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 100, 0));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 1));
                w.spawnParticle(Particle.SMOKE, p.getLocation().add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.02);
            }
            case SHRINK -> {
                AttributeInstance sc = p.getAttribute(Attribute.SCALE);
                if (sc == null) { refund(p); return; }
                sc.setBaseValue(0.5);
                shrunk.add(p.getUniqueId());
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 1));
                w.playSound(p.getLocation(), Sound.ENTITY_SLIME_SQUISH, 1f, 1.5f);
                Bukkit.getScheduler().runTaskLater(this, () -> unshrink(p), 160L);
            }
            case VAMPIRE -> {
                w.spawnParticle(Particle.DAMAGE_INDICATOR, p.getLocation().add(0, 1, 0), 30, 2, 1, 2);
                w.playSound(p.getLocation(), Sound.ENTITY_BAT_DEATH, 1f, 0.7f);
                for (LivingEntity le : w.getNearbyLivingEntities(p.getLocation(), 5)) {
                    if (le.equals(p)) continue;
                    le.damage(5, p);
                    heal(p, 3);
                }
            }
            case PULL -> {
                w.spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 60, 3, 1, 3, 0.5);
                w.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_STARE, 1f, 0.5f);
                for (LivingEntity le : w.getNearbyLivingEntities(p.getLocation(), 10)) {
                    if (le.equals(p)) continue;
                    Vector to = p.getLocation().toVector().subtract(le.getLocation().toVector());
                    if (to.lengthSquared() > 0) to.normalize().multiply(1.3);
                    le.setVelocity(to.setY(0.35));
                }
            }
            case METEOR -> {
                Location t = target(p, 40);
                if (t == null) { refund(p); return; }
                Location spawn = t.clone().add(0, 20, 0);
                w.spawn(spawn, Fireball.class, fb -> {
                    fb.setShooter(p);
                    fb.setDirection(new Vector(0, -1, 0));
                    fb.setVelocity(new Vector(0, -1.5, 0));
                    fb.setYield(5f);
                    fb.setIsIncendiary(false);
                });
                w.playSound(t, Sound.ENTITY_GHAST_SHOOT, 2f, 0.5f);
            }
            case SPEED_BURST -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 3));
                p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 160, 2));
                w.spawnParticle(Particle.CLOUD, p.getLocation(), 20, 0.3, 0.1, 0.3, 0.05);
            }
            case RAGE -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 200, 1));
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 1));
                w.spawnParticle(Particle.ANGRY_VILLAGER, p.getLocation().add(0, 2, 0), 10, 0.4, 0.3, 0.4);
                w.playSound(p.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1f, 1f);
            }
            case LAUNCH -> {
                w.spawnParticle(Particle.EXPLOSION, p.getLocation(), 2, 1, 0.1, 1);
                w.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1f, 1f);
                for (LivingEntity le : w.getNearbyLivingEntities(p.getLocation(), 6)) {
                    if (le.equals(p)) continue;
                    le.setVelocity(new Vector(0, 1.6, 0));
                }
            }
            case TIME_STOP -> {
                w.spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 60, 4, 1, 4, 0.01);
                w.playSound(p.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1f, 0.5f);
                for (LivingEntity le : w.getNearbyLivingEntities(p.getLocation(), 8)) {
                    if (le.equals(p)) continue;
                    le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 6));
                    le.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 100, 128));
                    le.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 2));
                }
            }
            case POISON -> {
                w.spawnParticle(Particle.SNEEZE, p.getLocation().add(0, 1, 0), 80, 3, 1, 3, 0.02);
                w.playSound(p.getLocation(), Sound.ENTITY_SPIDER_AMBIENT, 1f, 0.6f);
                for (LivingEntity le : w.getNearbyLivingEntities(p.getLocation(), 7)) {
                    if (le.equals(p)) continue;
                    le.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 120, 1));
                }
            }
            case SHIELD -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 4));
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 2));
                w.playSound(p.getLocation(), Sound.ITEM_TOTEM_USE, 0.6f, 1.5f);
            }
            case ARROW_RAIN -> {
                Location t = target(p, 40);
                if (t == null) { refund(p); return; }
                for (int i = 0; i < 25; i++) {
                    Location l = t.clone().add((rnd.nextDouble() - 0.5) * 6, 12 + rnd.nextDouble() * 4, (rnd.nextDouble() - 0.5) * 6);
                    w.spawn(l, Arrow.class, a -> {
                        a.setShooter(p);
                        a.setVelocity(new Vector(0, -2.0, 0));
                        a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                    });
                }
                w.playSound(t, Sound.ENTITY_ARROW_SHOOT, 2f, 0.6f);
            }
        }
        p.sendActionBar(Component.text("Uzyto: " + g.label, g.color));
    }

    private void refund(Player p) {
        cooldowns.remove(p.getUniqueId());
        p.sendActionBar(Component.text("Brak celu", NamedTextColor.RED));
    }

    private void unshrink(Player p) {
        if (!shrunk.remove(p.getUniqueId())) return;
        AttributeInstance sc = p.getAttribute(Attribute.SCALE);
        if (sc != null) sc.setBaseValue(1.0);
    }
}
